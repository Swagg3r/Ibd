import java.util.Set;
import java.util.HashSet;
 
public class Cage {
  private int NoCage;
  private String Fonction;
  private int NoAlle;
  private Set Gardiens = new HashSet();
  private Set Animals = new HashSet();


  public Cage(){}

  public Cage(int NoCage,String Fonction,int NoAlle){
	this.setFonction(Fonction);
	this.setNoAlle(NoAlle);
	this.setNoCage(NoCage);
  }

  public int getNoCage() {
    return NoCage;
  }

  public void setNoCage(int c) {
    NoCage = c;
  }
  
  public String getFonction() {
    return Fonction;
  }  

  public void setFonction(String f) {
    Fonction = f;
  }

  public int getNoAlle() {
    return NoAlle;
  }
 
  public void setNoAlle(int n) {
    NoAlle = n;
  }

  public Set getGardiens() {
    return Gardiens;
  }

  public void setGardiens(Set S) {
     Gardiens  = S;
  }

  public void addGardien(Gardien g) {
     Gardiens.add(g);
  }


  public Set getAnimals() {
    return Animals;
  }

  public void setAnimals(Set S) {
     Animals  = S;
  }

  public void addAnimal(Animal a) {
     Animals.add(a);
  }

  public void removeAnimal(Animal a) {
     Animals.remove(a);
  }

}
