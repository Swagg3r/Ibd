import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.io.*;
import java.util.*;

 
public class CreateZoo {




  public static void main(String[] args) {
    Session session = null;
    Configuration cf ;
    long id=0;
    try{
        // This step will read hibernate.cfg.xmland prepare hibernate for use
        
        System.out.println("Configuration \n");
        SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        
        System.out.println("Session \n");
		session = sessionFactory.openSession();
        
        System.out.println("Starting tx \n");
		Transaction tx = session.beginTransaction();

        // Cage 12
        Cage c = new Cage(12,"deer",10);session.save(c);
        Animal a = new Animal("Charly","male","lion","Kenya",2000,c); session.save(a);
        a = new Animal("Charlotte","female","lion","Kenya",2002,c); session.save(a);
        // Cage 11
        c = new Cage(11,"deer",10);session.save(c);
        a = new Animal("Milou","male","leopard","France",2003,c); session.save(a);
        a = new Animal("Tintin","male","leopard","France",2003,c); session.save(a);
        // Cage 1
        c = new Cage(1,"den",1);session.save(c);
        a = new Animal("Arthur","male","bear","France",2005,c); session.save(a);
        // Cage 2
        c = new Cage(2,"aquarium",1);session.save(c);
        // Cage 3
        c = new Cage(3,"small birds",2);session.save(c);
        a = new Animal("Chloe","female","magpie","France",2001,c); session.save(a);
        // Cage 4
        c = new Cage(4,"large aquarium",1);session.save(c);

/* Stuff to add in the DB
create_SUPERVISOR(10,"Phil");
create_SUPERVISOR(1,"Andrew");
create_SUPERVISOR(2,"Peter");

create_DISEASE("Charly","ragging toothache");
create_DISEASE("Charly","flu");
create_DISEASE("Milou","sore throat");
create_DISEASE("Chloe","flu");


create_EMPLOYE("Phil","Randwick");
create_EMPLOYE("Andrew","Botany Bay");
create_EMPLOYE("Peter","Townsville");
create_EMPLOYE("Mary","Sydney");
create_EMPLOYE("Michael","Manly");
create_EMPLOYE("Paul","Randwick");

create_GUARD(11,"Michael");
create_GUARD(12,"Mary");
create_GUARD(12,"Paul");
create_GUARD(11,"Mary");
create_GUARD(11,"Paul");
create_GUARD(1,"Michael");
create_GUARD(3,"Michael");
create_GUARD(12,"Michael");
*/
        
        System.out.println("attempting to commit tx \n");
		tx.commit();
	
        System.out.println("Zoo created \n");
    
        }catch(Exception e){
            System.out.println("catch !:");e.printStackTrace();
        }finally{
            session.close();
        }
    
    }
}
