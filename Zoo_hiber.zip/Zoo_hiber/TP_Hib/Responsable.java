import java.util.Set;
import java.util.HashSet;

public class Responsable extends Employe {
  private long NoAlle;

  public long getNoAlle() {
    return NoAlle;
  }
  
  public void setNoAlle(long n) {
    NoAlle = n;
  }
 
}
