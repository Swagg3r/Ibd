import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.*;


public class QueryZoo {
  
public static void main(String[] args) {
Session session = null;
Configuration cf;
List results;
Iterator iter;

try{
	// This step will read hibernate.cfg.xmland prepare hibernate for use
	System.out.println("Configuration \n");
	SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	
    System.out.println("Openning Session \n");
    session = sessionFactory.openSession();
    
    System.out.println("Starting Tx \n");
	Transaction tx = session.beginTransaction();

    System.out.println("Querying: from Animal\n");
    results = session.createQuery("from Animal").list();
	iter = results.iterator();
    System.out.println("Parsing Results \n");
    while (iter.hasNext()) {
    	Animal a = (Animal) iter.next();
    	System.out.println("\t"+a.getLaCage().getNoCage());
    }
    

    }catch(Exception e){
        System.out.println("catch !:");e.printStackTrace();
    }finally{
        try {session.flush();} catch(Exception e){
            System.out.println("finally catch !:");
            e.printStackTrace();
        };
        session.close();
    }
    
}

}
