@NamedQuery(name = "countItems", query = "select count(i) from Item i") package org.hibernate.ejb.test;

import org.hibernate.annotations.NamedQuery;

